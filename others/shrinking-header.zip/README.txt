A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/bMwJey.

 Want your header to shrink when you scroll? Here we have it. This uses a CSS3 transition for extra smoothness.

Why is this cool? On longer one-page websites its good to have the navigation fixed to the top as otherwise you can end up having to do a ton of scrolling. 

The shrinkage means that less screen space is wasted. Particularly useful for tablet and smaller screed devices.